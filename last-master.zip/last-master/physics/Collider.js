class Collider extends Component{
  constructor(geometry){
    super("Collider");
    this.Geometry = geometry;
  }
}