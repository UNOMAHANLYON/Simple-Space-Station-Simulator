class Behavior extends Component{
  constructor(name){
    super(name);
  }
}